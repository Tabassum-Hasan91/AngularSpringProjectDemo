export interface Employee
{
    name:string;
    empId:number;
    salary:number;
}