import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import {Employee} from '../employee'

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {

  emps=[];
  constructor(private emp:EmployeeService) { }

  ngOnInit(): void {
    this.emp.getEmployee().subscribe((data)=>{this.emps=data});
  }

  updateEmployee(empid:number,value:string,e:Employee):void
  {
    value=prompt("Enter the new name");
      this.emp.updateEmployee(empid,value,e).subscribe();
      alert("done");
  }

}
