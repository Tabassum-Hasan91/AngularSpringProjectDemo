import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  //public url:string="/assets/data/employees.json";
  public url:string="http://localhost:8182/employee";
  arr=[];
  constructor(private http:HttpClient) {
   }

   getEmployee():Observable<Employee[]>
   {
      return this.http.get<Employee[]>(this.url+'/employees');
      
   }

   updateEmployee(id: number,value:any, emp:Employee): Observable<Object> {
    //return this.http.put(`${this.url}/${id}`, value);
    return this.http.put(`${this.url}?userid=${id}&uname=${value}`,emp);
    
  }

  getEmployeeById(id: number): Observable<Object> {
    return this.http.get(`${this.url}/${id}`);
  }

}
