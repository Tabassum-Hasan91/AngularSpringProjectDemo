package com.niitCompany.projectDemo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee111")
public class Employee {
	@Column(name="name")
	String name;
	
	@Id
	@Column(name="empid")
	int empId;
	
	@Column(name="salary")
	double salary;
	
	Employee()
	{
		name="null";
		empId=0;
		salary=0.0;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}	
}
