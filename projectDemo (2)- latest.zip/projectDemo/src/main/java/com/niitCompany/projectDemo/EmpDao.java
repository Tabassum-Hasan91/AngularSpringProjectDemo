package com.niitCompany.projectDemo;

import java.util.List;

public interface EmpDao  {
	
	public boolean updateEmployee(Employee emp); 
	public List<Employee> getEmployees();  

}
