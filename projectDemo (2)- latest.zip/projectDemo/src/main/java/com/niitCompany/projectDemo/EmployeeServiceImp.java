package com.niitCompany.projectDemo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class EmployeeServiceImp implements EmployeeService{

	private List<Employee> employees;
	
	@Autowired
	private EmpDao empDao;
	
	public EmployeeServiceImp() {

		employees = new ArrayList<>();
		
		Employee emp1 = new Employee();
		emp1.setName("Tanmay");
		emp1.setEmpId(1);
		emp1.setSalary(3000.00);
		
		Employee emp2 = new Employee();
		emp2.setName("Gajju");
		emp2.setEmpId(2);
		emp2.setSalary(5000.00);
		
		Employee emp3 = new Employee();
		emp3.setName("Elson");
		emp3.setEmpId(3);
		emp3.setSalary(5000.00);
		
		employees.add(emp1);
		employees.add(emp2);
		employees.add(emp3);
	
	}
	
	@Override
	public Employee getEmployee(Integer userId) {
		//returns a user object
		return employees.stream().filter(x->x.getEmpId()==userId).findAny().
											orElse(new Employee());
	}

	@Override
	public void UpdateEmp(Integer userId, String username) {
		//in hibernate project this method will call update  method of the DAO class
		//empDao.updateEmp();
		//employees.stream().filter(x->x.getEmpId()==userId).findAny().orElseThrow(()->new RuntimeException("User not found")).setName(username);
		
		 //empDao.updateEmployee(emp);  
	}

	@Override
	public List<Employee> getAllUsers() {
		// TODO Auto-generated method stub
		//return employees;
		
		return empDao.getEmployees();
	}

}
