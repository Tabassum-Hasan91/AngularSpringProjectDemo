package com.niitCompany.projectDemo;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class EmployeeDAOImp  implements EmpDao
{
	@Autowired  
    private SessionFactory sessionFactory;  

	@Override
	public boolean updateEmployee(Employee emp) {
		boolean status=false;  
        try {  
            sessionFactory.getCurrentSession().update(emp);  
            status=true;  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
        return status;  
	}

	@Override
	public List<Employee> getEmployees() {
		 Session currentSession = sessionFactory.getCurrentSession();  
        Query<Employee> query=currentSession.createQuery("from Employee", Employee.class);  
        List<Employee> list=query.getResultList();  
        return list;  
	}

}
